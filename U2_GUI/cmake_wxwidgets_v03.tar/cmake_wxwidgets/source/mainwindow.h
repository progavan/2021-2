/************************************************************************************//**
* \file         mainwindow.h
* \brief        Application's main window header file.
*
****************************************************************************************/
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

/****************************************************************************************
* Include files
****************************************************************************************/
#include <wx/wx.h>

/****************************************************************************************
* Class definitions
****************************************************************************************/
/** \brief Application's main window class. */
class MainWindow : public wxFrame
{
public:
  MainWindow(const wxString& title, int width, int height);
 #if 1 //LMC 2021.12.07 
private:
  wxPanel * m_Panel;   
 #endif 
 #if 2 //LMC 2021.12.07 
 wxTextCtrl * m_EditBox;
 #endif 
};

#endif /* MAINWINDOW_H */
/*********************************** end of mainwindow.h *******************************/

